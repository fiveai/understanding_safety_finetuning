# #!/bin/bash

# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "pre_llama3" --tokenizer_size 0  --ckpt_dir llama-3-8b  --tokenizer_path ./llama-3-8b/./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "chat_llama3" --tokenizer_size 0  --ckpt_dir llama-3-8b-chat  --tokenizer_path ./llama-3-8b-chat/./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50

torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "chat"  --ckpt_dir llama-3-8b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a instruct_llama2.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "ppo_human" --tokenizer_size 32001  --ckpt_dir ppo-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "ppo_sim" --tokenizer_size 32001  --ckpt_dir ppo-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_sim.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "expiter_human" --tokenizer_size 32001  --ckpt_dir expiter-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "expiter_sim" --tokenizer_size 32001  --ckpt_dir expiter-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_sim.txt


torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "pretrained"  --ckpt_dir llama-3-8b  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a instruct_llama2.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "ppo_human" --tokenizer_size 32001  --ckpt_dir ppo-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "ppo_sim" --tokenizer_size 32001  --ckpt_dir ppo-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_sim.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "expiter_human" --tokenizer_size 32001  --ckpt_dir expiter-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "expiter_sim" --tokenizer_size 32001  --ckpt_dir expiter-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_sim.txt


torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "chat"  --ckpt_dir llama-3-8b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a instruct_llama2.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "ppo_human" --tokenizer_size 32001  --ckpt_dir ppo-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "ppo_sim" --tokenizer_size 32001  --ckpt_dir ppo-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_sim.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "expiter_human" --tokenizer_size 32001  --ckpt_dir expiter-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models_cosine.py --path_name "expiter_sim" --tokenizer_size 32001  --ckpt_dir expiter-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_sim.txt


torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "pretrained"  --ckpt_dir llama-3-8b  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a instruct_llama2.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "ppo_human" --tokenizer_size 32001  --ckpt_dir ppo-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "ppo_sim" --tokenizer_size 32001  --ckpt_dir ppo-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a ppo_sim.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "expiter_human" --tokenizer_size 32001  --ckpt_dir expiter-human  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_human.txt
# torchrun --nproc_per_node 1 sample_safe_unsafe_avg_diff_sample_var_new_all_models.py --path_name "expiter_sim" --tokenizer_size 32001  --ckpt_dir expiter-sim  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50 | tee -a expiter_sim.txt



# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.6 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.75 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.8 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.9 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1.1 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1.2 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1.25 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1.4 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1.5 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50

# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# # torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.1 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.25 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# # torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.3 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.4 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 0.5 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50

# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 1.75 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act.py --alpha 2 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50



# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# # torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.1 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.25 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# # torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.3 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.4 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.5 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.6 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.75 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.8 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 0.9 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1.1 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1.2 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1.25 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# #torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1.4 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1.5 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 1.75 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_new.py --alpha 2 --ckpt_dir2 llama-2-7b     --ckpt_dir llama-2-7b-chat  --tokenizer_path ./llama-3-8b-chat/tokenizer.model  --max_seq_len 50 --max_batch_size 50