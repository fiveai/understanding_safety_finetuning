import numpy as np
import matplotlib.pyplot as plt
import argparse
parser = argparse.ArgumentParser(description='Plot Making')
parser.add_argument('--alpha', default=1,type=float, metavar='W')
args = parser.parse_args()
safe_arr = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_ft_safe_num.npy")
unsafe_arr = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_ft_unsafe_num.npy")

safe_arr_pretrain = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_pt_safe_num.npy")
unsafe_arr_pretrain = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_pt_unsafe_num.npy")

# largest_value_safe_pre =  safe_arr_pretrain[:,0]
# # largest_value_unsafe_pre = unsafe_arr_pretrain[:,0]

# largest_value_safe_ft =  safe_arr[:,0]
# # largest_value_unsafe_ft = unsafe_arr[:,0]


# largest_value_safe_pre =  np.linalg.norm(safe_arr_pretrain,axis=1)
# # largest_value_unsafe_pre = np.linalg.norm(unsafe_arr_pretrain,axis=1)

# largest_value_safe_ft =  np.linalg.norm(safe_arr,axis=1)
# # largest_value_unsafe_ft = np.linalg.norm(unsafe_arr,axis=1)
energy_unsafe_pt_lst = []
energy_safe_pt_lst = []
energy_unsafe_lst = []
energy_safe_lst = []

# for layer_num in range(6):
#     temp = 10
#     # print("shape", np.exp(unsafe_arr/temp).shape)
#     energy_safe = -np.log(np.sum(np.exp(safe_arr[layer_num]/temp)))
#     energy_safe_pt = -np.log(np.sum(np.exp(safe_arr_pretrain[layer_num]/temp)))

#     energy_unsafe = -np.log(np.sum(np.exp(unsafe_arr[layer_num]/temp)))
#     energy_unsafe_pt = -np.log(np.sum(np.exp(unsafe_arr_pretrain[layer_num]/temp)))

#     energy_safe_lst.append(energy_safe)
#     energy_unsafe_lst.append(energy_unsafe)

#     energy_safe_pt_lst.append(energy_safe_pt)
#     energy_unsafe_pt_lst.append(energy_unsafe_pt)


safe_rank = np.linalg.norm(safe_arr,axis=1)**2/safe_arr[:,0]**2
unsafe_rank = np.linalg.norm(unsafe_arr,axis=1)**2/unsafe_arr[:,0]**2

safe_rank_pretrain = np.linalg.norm(safe_arr_pretrain,axis=1)**2/safe_arr_pretrain[:,0]**2
unsafe_rank_pretrain = np.linalg.norm(unsafe_arr_pretrain,axis=1)**2/unsafe_arr_pretrain[:,0]**2

diff_safe = safe_rank - safe_rank_pretrain
diff_unsafe = unsafe_rank - unsafe_rank_pretrain
# energy_unsafe = -np.log(np.sum(np.exp(unsafe_arr/temp),axis=1))
# energy_unsafe_pt = -np.log(np.sum(np.exp(unsafe_arr_pretrain/temp),axis=1))

# safe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_safe_num.npy")
# unsafe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_unsafe_num.npy")
# print("energy_unsafe",energy_unsafe)

colour_lst =  ['green', 'red', 'brown', 'pink', 'orange', 'brown']
marker_lst = ['o', '*', '+', '<', '>', '^']
# safe_arr_energy = np.linalg.norm(safe_arr,axis=1)**2
# unsafe_arr_energy = np.linalg.norm(unsafe_arr,axis=1)**2

# safe_arr_rank = np.linalg.norm(safe_arr,axis=1)**2/safe_arr[:,0]**2
# unsafe_arr_rank = np.linalg.norm(unsafe_arr,axis=1)**2/unsafe_arr[:,0]**2

plt.scatter(np.arange(np.array(diff_safe).shape[0]),np.array(diff_safe), color=colour_lst[0], marker=marker_lst[0],s=8,label='safe')
plt.scatter(np.arange(np.array(diff_unsafe).shape[0]),np.array(diff_unsafe), color=colour_lst[1], marker=marker_lst[1],s=8,label='unsafe')
# plt.scatter(np.arange(np.array(largest_value_unsafe_pre).shape[0]),np.array(largest_value_unsafe_pre), color=colour_lst[1], marker=marker_lst[0],s=8,label='unsafe-pre')

# plt.scatter(np.arange(np.array(energy_unsafe_lst).shape[0]),np.array(energy_unsafe_lst), color=colour_lst[1], marker=marker_lst[1],s=8,label='unsafe-ft')
# plt.scatter(np.arange(np.array(energy_unsafe_pt_lst).shape[0]),np.array(energy_unsafe_pt_lst), color=colour_lst[1], marker=marker_lst[0],s=8,label='unsafe-pre')

# plt.scatter(np.arange(np.array(diff_ft).shape[0]),np.array(diff_ft), color=colour_lst[1], marker=marker_lst[1],s=4,label='ft')
plt.legend()
plt.savefig("./llama_2b_act1_sing_activation_angle_mod_new_norm/diff_stable_rank.pdf".format(args.alpha))
plt.close('all')
