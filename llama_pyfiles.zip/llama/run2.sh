#!/bin/bash


torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_weight_cosine_safe_postavg.py  --nwords 32000 --ckpt_dir2 llama-2-7b  --path_name 'pre_chat'   --ckpt_dir  llama-2-7b-chat   --tokenizer_path tokenizer.model   --tokenizer_path2 tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50

# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_pposim'   --ckpt_dir ppo-sim  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_weight_cosine_unsafe_postavg.py  --nwords 32000 --ckpt_dir2 llama-2-7b  --path_name 'pre_chat'   --ckpt_dir llama-2-7b-chat  --tokenizer_path tokenizer.model   --tokenizer_path2 tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50



torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_weight_cosine_safe_postavg.py  --nwords 32001 --ckpt_dir2 llama-2-7b-instruct  --path_name 'ssft_expiter_human'   --ckpt_dir expiter-human  --tokenizer_path tokenizer.model   --tokenizer_path2 tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50

# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_pposim'   --ckpt_dir ppo-sim  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_alpha_new_singular_values_act_weight_cosine_unsafe_postavg.py  --nwords 32001 --ckpt_dir2 llama-2-7b-instruct  --path_name 'ssft_expiter_human'   --ckpt_dir expiter-human  --tokenizer_path tokenizer.model    --tokenizer_path2 tokenizer.model --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50







# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels2.py --ckpt_dir2 llama-2-7b  --path_name 'pre_chat'   --ckpt_dir llama-2-7b-chat  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py   --value_vocab 32001 --ckpt_dir2 llama-2-7b-instruct  --path_name 'ft_ppohuman'   --ckpt_dir ppo-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_unsafe_newmodels.py   --value_vocab 32001 --ckpt_dir2 llama-2-7b-instruct  --path_name 'ft_ppohuman'   --ckpt_dir ppo-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_pposim'   --ckpt_dir ppo-sim  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50

torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --value_vocab 32000  --ckpt_dir2 llama-2-7b  --path_name 'pre_ppohuman'   --ckpt_dir ppo-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_pposim'   --ckpt_dir ppo-sim  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_unsafe_newmodels.py --value_vocab 32000  --ckpt_dir2 llama-2-7b  --path_name 'pre_ppohuman'   --ckpt_dir ppo-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50

torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py  --value_vocab 32001 --ckpt_dir2 llama-2-7b-instruct  --path_name 'ft_expiter_human'   --ckpt_dir expiter-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels2.py --ckpt_dir2 llama-2-7b  --path_name 'pre_chat'   --ckpt_dir llama-2-7b-chat  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_pposim'   --ckpt_dir ppo-sim  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_unsafe_newmodels.py  --value_vocab 32001 --ckpt_dir2 llama-2-7b-instruct  --path_name 'ft_expiter_human'   --ckpt_dir expiter-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50



torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py  --value_vocab 32000 --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_human'   --ckpt_dir expiter-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50



# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_pposim'   --ckpt_dir ppo-sim  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_unsafe_newmodels.py  --value_vocab 32000 --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_human'   --ckpt_dir expiter-human  --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50
# torchrun --nproc_per_node 1 model_analysis_svd_compare_models_weights_costheta_act_diff_act_patch_newmodels.py --ckpt_dir2 llama-2-7b  --path_name 'pre_expiter_sim'   --ckpt_dir expiter-sim   --tokenizer_path tokenizer.model  --max_seq_len 50 --max_batch_size 50


