

from typing import List, Optional
import matplotlib.pyplot as plt
import fire
import numpy as np
from llama import Llama3, Dialog3
import matplotlib as mpl
from llama.model3 import ModelArgs3, Transformer3
from pathlib import Path
from fairscale.nn.model_parallel.initialize import (
    get_model_parallel_rank,
    initialize_model_parallel,
    model_parallel_is_initialized,
)
import os
import torch
from llama.tokenizer3 import Tokenizer3

import json
import os
import sys
import time
from pathlib import Path
import numpy as np
from typing import List, Literal, Optional, Tuple, TypedDict

def get_svd(arr):
    mu =  np.mean(arr, axis=0)
    arr = arr - mu
    U, S, V = np.linalg.svd(arr, full_matrices=True)
    return U,  V, S


# Harm: Benefit
# Slaughter: Preserve
# Steal: Return
# Explode: Implode
# Lacerate: Mend
# Kill: Spare
# Poison: Purify
# Enslave: Liberate
# Corrupt: Purify
# Plunder: Restore
# Sabotage: Aid
# Defraud: Uphold
# Slander: Praise
# Disrupt: Stabilize
# Hijack: Surrender
# Betray: Remain loyal
# Exploit: Assist
# Assassinate: Protect
# Destroy: Build
# Terrorize: Comfort
# Persecute: Protect
# Rape: Respect
# Kidnap: Release

def main(
    ckpt_dir: str,
    ckpt_dir2:str,
    tokenizer_path: str,
    temperature: float = 0.6,
    top_p: float = 0.9,
    max_seq_len: int = 512,
    max_batch_size: int = 8,
    max_gen_len: Optional[int] = None,
    model_parallel_size: Optional[int] = None,
    seed: int = 1,
):
    # generator = Llama_mod.build(
    #     ckpt_dir=ckpt_dir,
    #     tokenizer_path=tokenizer_path,
    #     max_seq_len=max_seq_len,
    #     max_batch_size=max_batch_size,
    # )

    lst_tokens_dict_safe = {'Benefit','Preserve', 'Return', 'Mend', 'Spare', 'Purify', 'Liberate', 'Purify', 'Restore', 'Aid', 'Uphold',
                            'Praise', 'Stabilize', 'Surrender', 'Loyal', 'Assist', 'Protect', 'Build', 'Comfort', 'Protect', 'Respect', 'Release'}


    lst_tokens_dict_unsafe = {
    'harm',
    'slaughter',
    'steal',
    'explode',
    'kill'
    'poison',
    'enslave',
    'corrupt',
    'sabotage',
    'defraud',
    'slander',
    'murder',
    'hijack',
    'betray',
    'exploit',
    'assassinate',
    'destroy',
    'terrorize',
    'persecute',
    'rape',
    'kidnap',
    }





    
    object_tokens = ["cycle", "story", "bomb", "building", "money", 'human', 'fruits', 'scissor', 'french']

    lst_tokens_safe = []
    lst_tokens_unsafe = []
    counter = 0
    breaker = 0
    for key in lst_tokens_dict_safe:
        lst_tokens_safe.append([{"role": "user", "content": key }])

    if not torch.distributed.is_initialized():
        torch.distributed.init_process_group("nccl")
    if not model_parallel_is_initialized():
        if model_parallel_size is None:
            model_parallel_size = int(os.environ.get("WORLD_SIZE", 1))
        initialize_model_parallel(model_parallel_size)


    # local_rank = int(os.environ.get("LOCAL_RANK", 0))
    # torch.cuda.set_device(local_rank)

    # # seed must be the same in all processes
    # torch.manual_seed(seed)

    # if local_rank > 0:
    #     sys.stdout = open(os.devnull, "w")

    # start_time = time.time()

    checkpoints = sorted(Path(ckpt_dir).glob("*.pth"))

    ckpt_path = checkpoints[get_model_parallel_rank()]
    checkpoint = torch.load(ckpt_path, map_location="cpu")

    checkpoints2 = sorted(Path(ckpt_dir2).glob("*.pth"))
    ckpt_path2 = checkpoints2[get_model_parallel_rank()]
    checkpoint2 = torch.load(ckpt_path2, map_location="cpu")



    with open(Path(ckpt_dir) / "params.json", "r") as f:
        params = json.loads(f.read())

    model_args: ModelArgs3 = ModelArgs3(
        max_seq_len=max_seq_len,
        max_batch_size=max_batch_size,
        **params,
    )

    tokenizer = Tokenizer3(model_path=tokenizer_path)
    model_args.vocab_size = tokenizer.n_words
    

    model = Transformer3(model_args)
    model.load_state_dict(checkpoint, strict=False)


    model2 = Transformer3(model_args)
    model2.load_state_dict(checkpoint2, strict=False)
    model_test = Transformer3(model_args)

    model_test.load_state_dict(model.state_dict())
    model_test.eval()
    generator = Llama3(model_test, tokenizer)

    print("Generator", generator)

    generator_pretrain = Llama3(model2, tokenizer)

    print("Generator pretrain", generator_pretrain)

    # generator = Llama.build(
    #     ckpt_dir=ckpt_dir,
    #     tokenizer_path=tokenizer_path,
    #     max_seq_len=max_seq_len,
    #     max_batch_size=max_batch_size,
    #     state_load = dict_model_test,
    #     load_model = 1,
    # )

    counter = 0
    breaker = 0
    for key in lst_tokens_dict_unsafe:
        lst_tokens_unsafe.append([{"role": "user", "content": key}])

    lst_temp_unsafe = []
    lst_temp_safe = []
    start_idx = 0
    lst_all = []
    lst_all_pre = []
    lst_all_new = []
    lst_all_pre_new = []
    lst_ft = []
    for i in range(len(lst_tokens_unsafe)//max_batch_size+1):
        dialogs: List[Dialog3] = lst_tokens_unsafe[start_idx:start_idx+max_batch_size]
        start_idx+=max_batch_size
        print("dialogs",dialogs)
        results, neuron_act_unsafe_orig = generator.chat_completion(
            dialogs,  # type: ignore
            max_gen_len=max_gen_len,
            temperature=temperature,
            top_p=top_p,
        )
        lst_all.append(neuron_act_unsafe_orig)
        print("neuron_act_unsafe_orig shape",neuron_act_unsafe_orig.shape)
        neuron_act_unsafe_orig = neuron_act_unsafe_orig[0]


    lst_temp_unsafe = []
    lst_temp_safe = []
    start_idx = 0
    lst_all = []
    lst_all_pre = []
    lst_all_new = []
    lst_all_pre_new = []
    lst_ft = []
    for i in range(len(lst_tokens_safe)//max_batch_size+1):
        dialogs: List[Dialog3] = lst_tokens_safe[start_idx:start_idx+max_batch_size]
        results, neuron_act_safe = generator_pretrain.chat_completion(
            dialogs,  # type: ignore
            max_gen_len=max_gen_len,
            temperature=temperature,
            top_p=top_p,
        )
        lst_all_new.append(neuron_act_safe)
        neuron_act_safe = neuron_act_safe[0]
        # neuron_act_safe = np.array(neuron_act_safe).view(-1,neuron_act_safe.shape[-1])


        for idx in range(len(neuron_act_safe)):
            for idx2 in range(4,9):
                theta_unsafe = np.sum(np.dot(neuron_act_safe[idx][idx2], neuron_act_unsafe_orig[idx][idx2]))/(np.linalg.norm(neuron_act_unsafe_orig[idx][idx2])*np.linalg.norm(neuron_act_safe[idx][idx2]))
                lst_ft.append(theta_unsafe)
        print("lst_ft",lst_ft)

    #neuron_act_safe = np.reshape(np.array(lst_temp), (-1, neuron_act_safe.shape[1], neuron_act_safe.shape[2], neuron_act_safe.shape[3]))
    ft_arr = np.array(lst_ft)
    np.save("arr_emb_unsafe_test.npy",ft_arr)



if __name__ == "__main__":
    fire.Fire(main)
