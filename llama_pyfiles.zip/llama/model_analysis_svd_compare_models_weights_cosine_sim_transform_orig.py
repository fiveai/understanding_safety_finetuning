

from typing import List, Optional
import matplotlib.pyplot as plt
import fire
import numpy as np
from llama import Llama, Dialog
import matplotlib as mpl
from llama.model import ModelArgs, Transformer
from pathlib import Path
from fairscale.nn.model_parallel.initialize import (
    get_model_parallel_rank,
    initialize_model_parallel,
    model_parallel_is_initialized,
)
import os
import torch
from llama.tokenizer import Tokenizer

import json
import os
import sys
import time
from pathlib import Path
import numpy as np
from typing import List, Literal, Optional, Tuple, TypedDict

def get_svd(arr):
    mu =  np.mean(arr, axis=0)
    arr = arr - mu
    U, S, V = np.linalg.svd(arr, full_matrices=True)
    return U,  V, S

def interpolate_state_dicts_forward(state_dict_1, state_dict_2, weight):
    return {key: (weight) * state_dict_1[key] + (1-weight) * state_dict_2[key]
            for key in state_dict_1.keys()}


def get_index_value(sing_values_safe_pretrain, sing_values_unsafe_pretrain):

    index_safe = 0
    index_unsafe = 0

    running_mean = 0
    running_mean2 = 0

    for i in range(len(sing_values_safe_pretrain)):
        running_mean+=sing_values_safe_pretrain[i]**2
    for j in range(len(sing_values_safe_pretrain)):
        running_mean2+=sing_values_safe_pretrain[j]**2
        if running_mean2/running_mean>0.9:
            index_safe = j
            break

    running_mean = 0
    running_mean2 = 0

    for i in range(len(sing_values_unsafe_pretrain)):
        running_mean+=sing_values_unsafe_pretrain[i]**2
    for j in range(len(sing_values_unsafe_pretrain)):
        running_mean2+=sing_values_unsafe_pretrain[j]**2
        if running_mean2/running_mean>0.9:
            index_unsafe = j
            break
    
    return index_safe, index_unsafe




def main(
    ckpt_dir: str,
    ckpt_dir2:str,
    tokenizer_path: str,
    temperature: float = 0.6,
    top_p: float = 0.9,
    max_seq_len: int = 512,
    max_batch_size: int = 8,
    max_gen_len: Optional[int] = None,
    model_parallel_size: Optional[int] = None,
    seed: int = 1,
    layer_num: int = 31,
):
    # generator = Llama_mod.build(
    #     ckpt_dir=ckpt_dir,
    #     tokenizer_path=tokenizer_path,
    #     max_seq_len=max_seq_len,
    #     max_batch_size=max_batch_size,
    # )



    # print(generator2)
    # a+=1
    if not torch.distributed.is_initialized():
        torch.distributed.init_process_group("nccl")
    if not model_parallel_is_initialized():
        if model_parallel_size is None:
            model_parallel_size = int(os.environ.get("WORLD_SIZE", 1))
        initialize_model_parallel(model_parallel_size)

    checkpoints = sorted(Path(ckpt_dir).glob("*.pth"))

    ckpt_path = checkpoints[get_model_parallel_rank()]
    checkpoint = torch.load(ckpt_path, map_location="cpu")

    checkpoints2 = sorted(Path(ckpt_dir2).glob("*.pth"))
    ckpt_path2 = checkpoints2[get_model_parallel_rank()]
    checkpoint2 = torch.load(ckpt_path2, map_location="cpu")



    with open(Path(ckpt_dir) / "params.json", "r") as f:
        params = json.loads(f.read())

    model_args: ModelArgs = ModelArgs(
        max_seq_len=max_seq_len,
        max_batch_size=max_batch_size,
        **params,
    )

    tokenizer = Tokenizer(model_path=tokenizer_path)
    model_args.vocab_size = tokenizer.n_words

    model = Transformer(model_args)
    model.load_state_dict(checkpoint, strict=False)

    model2 = Transformer(model_args)
    model2.load_state_dict(checkpoint2, strict=False)

    model_test = Transformer(model_args)

    counter_val=19
    fig, axs = plt.subplots(4, 3, figsize=(8, 5))
    alpha_lst = [1]
    lst_val_unsafe2 = []

    for layer_num in range(32):
  
        val_arr = model2.layers[layer_num].feed_forward.w1.weight.detach().cpu().numpy()
        val_arr_diff = model.layers[layer_num].feed_forward.w1.weight.detach().cpu().numpy() - model2.layers[layer_num].feed_forward.w1.weight.detach().cpu().numpy()
        left_sv_safe, right_sv_safe, sing_values_safe = get_svd(val_arr)
        left_sv_safe2, right_sv_safe2, sing_values_safe2 = get_svd(val_arr_diff)

        index_value_safe, index_value_unsafe = get_index_value(sing_values_safe, sing_values_safe)
        index_value_safe_diff, index_value_unsafe_diff = get_index_value(sing_values_safe2, sing_values_safe2)


        lst_sim = []
        lst_sim2 = []
        lst_sim_transform = []

        for i in range(index_value_safe):
            lst_sim.append(left_sv_safe[i])
        for i in range(index_value_safe):
            lst_sim_transform.append(left_sv_safe2[i])


        arr_sim = np.transpose(np.array(lst_sim))
        arr_sim_transpose = np.transpose(arr_sim)

        # arr_sim2 = np.transpose(np.array(lst_sim2))
        # arr_sim2_transpose = np.transpose(arr_sim2)



        proj_arr = np.matmul(arr_sim, arr_sim_transpose)
        # print("proj_arr", proj_arr.shape)
        lst_val_safe = []
        lst_val_unsafe = []

        for i in range(index_value_safe):
            proj_safe = np.matmul(proj_arr, lst_sim_transform[i])
            # proj_safe_null = np.matmul(np.transpose(proj_arr), lst_sim[i])
            theta_safe = np.sin(np.arccos(np.matmul(np.transpose(proj_safe),lst_sim_transform[i])/(np.linalg.norm(proj_safe)*np.linalg.norm(lst_sim_transform[i]))))
            lst_val_safe.append(theta_safe)

    
        #plt.scatter(np.arange(len(lst_val_safe)), np.array(lst_val_safe),color='red',s=4)
        print(lst_val_safe)
        plt.scatter(np.arange(len(lst_val_safe)), np.array(lst_val_safe),color='red',s=1)
        np.save("./cos_sim_llama/" + 'feed_forward1_layer_{}'.format(layer_num) + ".npy", np.array(lst_val_safe))
        plt.savefig("./cos_sim_llama/" + 'feed_forward1_layer_{}'.format(layer_num) + ".pdf")
        plt.close('all')



if __name__ == "__main__":
    fire.Fire(main)



