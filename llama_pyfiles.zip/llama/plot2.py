import numpy as np
import matplotlib.pyplot as plt
import argparse
parser = argparse.ArgumentParser(description='Plot Making')
parser.add_argument('--alpha', default=1,type=int, metavar='W')
args = parser.parse_args()
safe_arr = np.load("llama_2b_act1_sing_activation_angle_mod_correct/alpha_1_layer_{}_safe_num.npy".format(args.alpha))[:100]
unsafe_arr = np.load("llama_2b_act1_sing_activation_angle_mod_correct/alpha_1_layer_{}_unsafe_num.npy".format(args.alpha))[:100]

# safe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_safe_num.npy")
# unsafe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_unsafe_num.npy")

colour_lst =  ['green', 'red', 'brown', 'pink', 'orange', 'brown']
marker_lst = ['o', '*', '+', '<', '>', '^']
# safe_arr_energy = np.linalg.norm(safe_arr,axis=1)**2
# unsafe_arr_energy = np.linalg.norm(unsafe_arr,axis=1)**2

# safe_arr_rank = np.linalg.norm(safe_arr,axis=1)**2/safe_arr[:,0]**2
# unsafe_arr_rank = np.linalg.norm(unsafe_arr,axis=1)**2/unsafe_arr[:,0]**2

plt.scatter(np.arange(np.array(safe_arr).shape[0]),np.array(safe_arr), color=colour_lst[0], marker=marker_lst[0],s=4)
plt.scatter(np.arange(np.array(unsafe_arr).shape[0]),np.array(unsafe_arr), color=colour_lst[1], marker=marker_lst[1],s=4)
plt.savefig("./llama_2b_act1_sing_activation_angle_mod_new_correct/alpha_1_layer_{}_diff.pdf".format(args.alpha))
plt.close('all')
