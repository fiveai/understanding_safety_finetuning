
import pickle 
import numpy as np
import pickle
import argparse
import os
import time
import random
import torch
import wandb
import os
from torch.utils.data.dataloader import DataLoader
import matplotlib.pyplot as plt
import matplotlib as mpl

parser = argparse.ArgumentParser(description='PyTorch CIFAR TRADES Adversarial Training')
parser.add_argument('--layer_num', type=int, default=1, metavar='N',
                    help='retrain from which epoch')
args = parser.parse_args()

value_ft = np.load("lipschitzness_analysis_plots/ft_unsafe.npy")
value_pt = np.load("lipschitzness_analysis_plots/pt_unsafe.npy")
value_emb = np.load("lipschitzness_analysis_plots/emb_unsafe.npy")
# value_emb = value_emb[:,:,:,0]
print("value_ft shape",value_ft.shape)
print("value_emb shape",value_emb.shape)

lst_max_ft = []
lst_max_pt = []
# value_ft[np.isnan(value_ft)] = 0
# value_pt[np.isnan(value_pt)] = 0
# print(value_ft[:,1])
lst_value_ft = []
lst_value_pt = []


for j in range(19900):
    temp_lst_ft = []
    temp_lst_pt = []
    den = np.sqrt(np.sum(value_emb[j,:9]/9))
    for i in range(32):
        value1 = np.sqrt(np.sum(value_ft[j,:9,i]/9))
        value2 = np.sqrt(np.sum(value_pt[j,:9,i]/9))
        if den==0:
            lips_ft=0
            lips_pt=0
        else:
            lips_ft = value1/den
            lips_pt = value2/den
        temp_lst_ft.append(lips_ft)
        temp_lst_pt.append(lips_pt)

    lst_value_ft.append(temp_lst_ft)
    lst_value_pt.append(temp_lst_pt)

lst_value_ft = np.array(lst_value_ft)
lst_value_pt = np.array(lst_value_pt)

# for i in range(32):
#     # lst_max_ft.append(np.max(lst_value_ft[:,i]))
#     # lst_max_pt.append(np.max(lst_value_pt[:,i]))
#     print(lst_value_ft[:,i])
#     lst_max_ft.append(np.max(lst_value_ft[:,i]))
#     lst_max_pt.append(np.max(lst_value_pt[:,i]))



print("lst_max_ft",lst_value_ft)
print("lst_max_pt",lst_value_pt)


# bins=range(int(min(lst_value_pt)),int(max(lst_value_pt)) +1, 1)

plt.hist(lst_value_pt[:,args.layer_num],label='pt',alpha=0.5)
plt.hist(lst_value_ft[:,args.layer_num],label='ft',alpha=0.5)
plt.legend()
plt.savefig("./lipschitzness_analysis_plots_new/unsafe_AM_plt_avg_{}.pdf".format(args.layer_num))
plt.close()