import numpy as np
import matplotlib.pyplot as plt
import argparse
parser = argparse.ArgumentParser(description='Plot Making')
parser.add_argument('--alpha', default=1,type=float, metavar='W')
args = parser.parse_args()
safe_arr = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_ft_safe_num.npy")
unsafe_arr = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_ft_unsafe_num.npy")

safe_arr_pretrain = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_pt_safe_num.npy")
unsafe_arr_pretrain = np.load("llama_2b_act1_sing_activation_angle_mod_correct/sing_pt_unsafe_num.npy")

# largest_value_safe_pre =  safe_arr_pretrain[:,0]
# largest_value_unsafe_pre = unsafe_arr_pretrain[:,0]

# largest_value_safe_ft =  safe_arr[:,0]
# largest_value_unsafe_ft = unsafe_arr[:,0]



# largest_value_safe_pre =  np.linalg.norm(safe_arr_pretrain,axis=1)
# largest_value_unsafe_pre = np.linalg.norm(unsafe_arr_pretrain,axis=1)

# largest_value_safe_ft =  np.linalg.norm(safe_arr,axis=1)
# largest_value_unsafe_ft = np.linalg.norm(unsafe_arr,axis=1)


largest_value_safe_pre =  np.linalg.norm(safe_arr_pretrain,axis=1)**2/safe_arr_pretrain[:,0]**2
largest_value_unsafe_pre = np.linalg.norm(unsafe_arr_pretrain,axis=1)**2/unsafe_arr_pretrain[:,0]**2

largest_value_safe_ft =  np.linalg.norm(safe_arr,axis=1)**2/safe_arr[:,0]**2
largest_value_unsafe_ft = np.linalg.norm(unsafe_arr,axis=1)**2/unsafe_arr[:,0]**2


# diff_pre = largest_value_safe_pre - largest_value_unsafe_pre
# diff_ft = largest_value_safe_ft - largest_value_unsafe_ft


# safe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_safe_num.npy")
# unsafe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_unsafe_num.npy")

colour_lst =  ['green', 'red', 'brown', 'pink', 'orange', 'brown']
marker_lst = ['o', '*', '+', '<', '>', '^']
# safe_arr_energy = np.linalg.norm(safe_arr,axis=1)**2
# unsafe_arr_energy = np.linalg.norm(unsafe_arr,axis=1)**2

# safe_arr_rank = np.linalg.norm(safe_arr,axis=1)**2/safe_arr[:,0]**2
# unsafe_arr_rank = np.linalg.norm(unsafe_arr,axis=1)**2/unsafe_arr[:,0]**2

plt.scatter(np.arange(np.array(largest_value_safe_pre).shape[0]),np.array(largest_value_safe_pre), color=colour_lst[0], marker=marker_lst[0],s=4,label='safe')
plt.scatter(np.arange(np.array(largest_value_unsafe_pre).shape[0]),np.array(largest_value_unsafe_pre), color=colour_lst[1], marker=marker_lst[1],s=4,label='unsafe')


# plt.scatter(np.arange(np.array(largest_value_safe_ft).shape[0]),np.array(largest_value_safe_ft), color=colour_lst[0], marker=marker_lst[0],s=4,label='safe')
# plt.scatter(np.arange(np.array(largest_value_unsafe_ft).shape[0]),np.array(largest_value_unsafe_ft), color=colour_lst[1], marker=marker_lst[1],s=4,label='unsafe')

plt.legend()
plt.savefig("./llama_2b_act1_sing_activation_angle_mod_new_norm/stable_rank_pre.pdf".format(args.alpha))
plt.close('all')
