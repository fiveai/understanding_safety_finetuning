import numpy as np
import matplotlib.pyplot as plt
import argparse
parser = argparse.ArgumentParser(description='Plot Making')
parser.add_argument('--alpha', default=1,type=float, metavar='W')
args = parser.parse_args()
safe_arr = np.load("llama_2b_act1_sing_activation_mod/alpha_all_{}_safe_num.npy".format(args.alpha))
unsafe_arr = np.load("llama_2b_act1_sing_activation_mod/alpha_all_{}_unsafe_num.npy".format(args.alpha))

# safe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_safe_num.npy")
# unsafe_arr_pretrain = np.load("llama_2b_act1_sing_activation_new_mod_new/alpha_all_0_unsafe_num.npy")

colour_lst =  ['green', 'red', 'brown', 'pink', 'orange', 'brown']
marker_lst = ['o', '*', '+', '<', '>', '^']
safe_arr_energy = np.linalg.norm(safe_arr,axis=1)**2
unsafe_arr_energy = np.linalg.norm(unsafe_arr,axis=1)**2

safe_arr_rank = np.linalg.norm(safe_arr,axis=1)**2/safe_arr[:,0]**2
unsafe_arr_rank = np.linalg.norm(unsafe_arr,axis=1)**2/unsafe_arr[:,0]**2

plt.scatter(np.arange(np.array(safe_arr_energy).shape[0]),np.array(safe_arr_energy), color=colour_lst[0], marker=marker_lst[0],s=4)
plt.scatter(np.arange(np.array(unsafe_arr_energy).shape[0]),np.array(unsafe_arr_energy), color=colour_lst[1], marker=marker_lst[1],s=4)
plt.ylim(0, 25000)
plt.savefig("./llama_2b_act1_sing_activation_mod/alpha_{}_diff.pdf".format(args.alpha))
plt.close('all')

plt.scatter(np.arange(np.array(safe_arr_rank).shape[0]),np.array(safe_arr_rank), color=colour_lst[0], marker=marker_lst[0],s=4)
plt.scatter(np.arange(np.array(unsafe_arr_rank).shape[0]),np.array(unsafe_arr_rank), color=colour_lst[1], marker=marker_lst[1],s=4)
plt.ylim(0, 9)
plt.savefig("./llama_2b_act1_sing_activation_new_mod_new/alpha_{}_diff.pdf".format(args.alpha))
plt.close('all')