
import pickle 
import numpy as np
import pickle
import argparse
import os
import time
import random
import torch
import wandb
import os
from torch.utils.data.dataloader import DataLoader
import matplotlib.pyplot as plt
import matplotlib as mpl
import argparse
parser = argparse.ArgumentParser(description='Plot Making')
# parser.add_argument('--path_safe', default='1',type=str, metavar='W')
# parser.add_argument('--path_unsafe', default='1',type=str, metavar='W')
parser.add_argument('--path_name', default='chat',type=str, metavar='W')
args = parser.parse_args()

# arr_path_safe = np.load("angle_analysis_new_{}/".format(args.path_name)+ args.path_safe)[:100]
# arr_path_unsafe = np.load("angle_analysis_new_{}/".format(args.path_name) + args.path_unsafe)[:100]
for layer_num in range(32):
    arr_path_safe = np.load("angle_analysis_new_{}/".format(args.path_name)+'alpha_1_layer_{}_safe_num.npy'.format(layer_num))[:100]
    arr_path_unsafe = np.load("angle_analysis_new_{}/".format(args.path_name)+'alpha_1_layer_{}_unsafe_num.npy'.format(layer_num))[:100]
    plt.scatter(np.arange(len(arr_path_unsafe)), arr_path_unsafe,color='red',label='unsafe',s=1)
    plt.scatter(np.arange(len(arr_path_safe)), arr_path_safe,color='green', label='safe',s=1)
    plt.legend()
    plt.savefig("./angle_analysis_new_{}/layer_num_{}.pdf".format(args.path_name, layer_num))
    plt.close('all')
