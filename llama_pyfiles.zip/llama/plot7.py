
import pickle 
import numpy as np
import pickle
import argparse
import os
import time
import random
import torch
import wandb
import os
from torch.utils.data.dataloader import DataLoader
import matplotlib.pyplot as plt
import matplotlib as mpl
import argparse
parser = argparse.ArgumentParser(description='Plot Making')
parser.add_argument('--path_l2', default='1',type=str, metavar='W')
parser.add_argument('--path_l2_theory', default='1',type=str, metavar='W')
parser.add_argument('--path_cos', default='1',type=str, metavar='W')
parser.add_argument('--path_name', default='chat',type=str, metavar='W')
args = parser.parse_args()

l2 = np.load(args.path_l2)
l2_theory = np.load(args.path_l2_theory)
cos = np.load(args.path_cos)
for layer_num in range(32):
    plt.scatter(cos[layer_num], l2[layer_num],color='red',label='emp',s=1)
    plt.scatter(cos[layer_num], l2_theory[layer_num],color='green', label='theory',s=1)
    plt.legend()
    plt.savefig("./cosine_analysis_{}/layer_num_{}.pdf".format(args.path_name, layer_num))
    plt.close('all')
