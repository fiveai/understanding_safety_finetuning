
import pickle 
import numpy as np
import pickle
import argparse
import os
import time
import random
import torch
import wandb
import os
from torch.utils.data.dataloader import DataLoader
import matplotlib.pyplot as plt
import matplotlib as mpl

lst_unsafe_ft = pickle.load(open( "lipschitzness_analysis/unsafe_ft.p", "rb" ) )
lst_unsafe_emb = pickle.load(open( "lipschitzness_analysis/unsafe_ft_emb.p", "rb" ) )
lst_unsafe_pt = pickle.load(open( "lipschitzness_analysis/unsafe_pt.p", "rb" ) )
# lst_unsafe_pt_emb = pickle.load(open( "lipschitzness_analysis/unsafe_pt_emb.p", "rb" ) )
lst_unsafe_emb_new = []
for i in range(len(lst_unsafe_emb)):
    lst_unsafe_emb_mod = []
    for j in range(len(lst_unsafe_emb[i])):
        if j==0:
            for k in range(9):
                append_value = lst_unsafe_emb[i][j][:,k,:]
                lst_unsafe_emb_mod.append(append_value)
        else:
                lst_unsafe_emb_mod.append(lst_unsafe_emb[i][j][:,0,:])
    lst_unsafe_emb_new.append(lst_unsafe_emb_mod)
    # lst_unsafe_ft = np.array(lst_unsafe_ft)
    # lst_unsafe_pt = np.array(lst_unsafe_pt)
    # lst_unsafe_emb = np.array(lst_unsafe_emb)
for i in range(len(lst_unsafe_ft)):
    lst_unsafe_ft[i] = np.swapaxes(np.array(lst_unsafe_ft[i]), 0,1)
    lst_unsafe_pt[i] = np.swapaxes(np.array(lst_unsafe_pt[i]), 0,1)
    lst_unsafe_emb_new[i] = np.swapaxes(np.array(lst_unsafe_emb_new[i]), 0,1)

print(lst_unsafe_ft[0].shape)
print(len(lst_unsafe_ft))

print(lst_unsafe_emb_new[0].shape)
print(len(lst_unsafe_emb_new))

print(lst_unsafe_pt[0].shape)
print(len(lst_unsafe_pt))

# arr_ft = np.reshape(np.array(lst_unsafe_ft), [50*4, 38, 32,11008])
# arr_pt = np.reshape(np.array(lst_unsafe_pt), [50*4, 38, 32,11008])
# arr_emb = np.reshape(np.array(lst_unsafe_emb_new), [50*4, 47,4096])

arr_ft = []
arr_pt = []
arr_emb = []
for i in range(len(lst_unsafe_pt)):
    for j in range(len(lst_unsafe_pt[i])):
        arr_ft.append(lst_unsafe_ft[i][j][:,:,0,:])
        arr_pt.append(lst_unsafe_pt[i][j][:,:,0,:])
        arr_emb.append(lst_unsafe_emb_new[i][j])


lst_ft = []
lst_pt = []
lst_emb = []
for i in range(len(arr_ft)):
    print("counter:",i)
    for j in range(len(arr_ft)):
        if i==j:
            continue
        else:
  
            norm_num = np.linalg.norm(arr_ft[i][:36] - arr_ft[j][:36],axis=-1)**2
            norm_num_pt = np.linalg.norm(arr_pt[i][:36] - arr_pt[j][:36],axis=-1)**2
            norm_den = np.linalg.norm(arr_emb[i][:36]-arr_emb[j][:36],axis=-1)**2

        # print("norm_den shape", norm_den.shape)
        # print("norm_num shape", norm_num.shape)
        # print("norm_num_pt shape", norm_num_pt.shape)

        lst_ft.append(norm_num)
        lst_pt.append(norm_num_pt)   
        lst_emb.append(norm_den)         
        
        # print("ft_lips",ft_lips)
        # print("pt_lips",pt_lips)

np.save("lipschitzness_analysis_plots/ft_unsafe.npy",np.array(lst_ft))
np.save("lipschitzness_analysis_plots/pt_unsafe.npy",np.array(lst_pt))
np.save("lipschitzness_analysis_plots/emb_unsafe.npy",np.array(lst_emb))

# bins=range(int(min(pt_lips)),int(max(pt_lips)) +1, 1)

# plt.hist(np.array(ft_lips),label='ft',alpha=0.5,bins=bins)
# plt.hist(np.array(pt_lips),label='pt',alpha=0.5,bins=bins)
# plt.legend()
# plt.savefig("./lipschitzness_analysis_plots/unsafe_AM.pdf")
# plt.close()