

from typing import List, Optional
import matplotlib.pyplot as plt
import fire
import numpy as np
from llama import Llama, Dialog
import matplotlib as mpl
from llama.model import ModelArgs, Transformer
from pathlib import Path
from fairscale.nn.model_parallel.initialize import (
    get_model_parallel_rank,
    initialize_model_parallel,
    model_parallel_is_initialized,
)
import os
import torch
from llama.tokenizer import Tokenizer

import json
import os
import sys
import time
from pathlib import Path
import numpy as np
from typing import List, Literal, Optional, Tuple, TypedDict

def get_svd(arr):
    mu =  np.mean(arr, axis=0)
    arr = arr - mu
    U, S, V = np.linalg.svd(arr, full_matrices=True)
    return U,  V, S

def interpolate_state_dicts_forward(state_dict_1, state_dict_2, weight):
    return {key: (weight) * state_dict_1[key] + (1-weight) * state_dict_2[key]
            for key in state_dict_1.keys()}





def main(
    ckpt_dir: str,
    ckpt_dir2:str,
    tokenizer_path: str,
    temperature: float = 0.6,
    top_p: float = 0.9,
    max_seq_len: int = 512,
    max_batch_size: int = 8,
    max_gen_len: Optional[int] = None,
    model_parallel_size: Optional[int] = None,
    seed: int = 1,
    layer_num: int = 31,
):
    # generator = Llama_mod.build(
    #     ckpt_dir=ckpt_dir,
    #     tokenizer_path=tokenizer_path,
    #     max_seq_len=max_seq_len,
    #     max_batch_size=max_batch_size,
    # )


    # print(generator2)
    # a+=1
    if not torch.distributed.is_initialized():
        torch.distributed.init_process_group("nccl")
    if not model_parallel_is_initialized():
        if model_parallel_size is None:
            model_parallel_size = int(os.environ.get("WORLD_SIZE", 1))
        initialize_model_parallel(model_parallel_size)

    checkpoints = sorted(Path(ckpt_dir).glob("*.pth"))

    ckpt_path = checkpoints[get_model_parallel_rank()]
    checkpoint = torch.load(ckpt_path, map_location="cpu")

    checkpoints2 = sorted(Path(ckpt_dir2).glob("*.pth"))
    ckpt_path2 = checkpoints2[get_model_parallel_rank()]
    checkpoint2 = torch.load(ckpt_path2, map_location="cpu")



    with open(Path(ckpt_dir) / "params.json", "r") as f:
        params = json.loads(f.read())

    model_args: ModelArgs = ModelArgs(
        max_seq_len=max_seq_len,
        max_batch_size=max_batch_size,
        **params,
    )

    tokenizer = Tokenizer(model_path=tokenizer_path)
    model_args.vocab_size = tokenizer.n_words

    model = Transformer(model_args)
    model.load_state_dict(checkpoint, strict=False)

    model2 = Transformer(model_args)
    model2.load_state_dict(checkpoint2, strict=False)

    model_test = Transformer(model_args)

    print("Model", model)
    counter_val=19
    fig, axs = plt.subplots(4, 3, figsize=(8, 5))
    alpha_lst = [0, 0.2, 0.4, 0.5, 0.6, 0.8, 1, 1.1, 1.2, 1.4, 1.5,2]
    for alpha in alpha_lst:
        counter_val+=1
        dict_model_test = interpolate_state_dicts_forward(model.state_dict(), model2.state_dict(), alpha)
        model_test.load_state_dict(dict_model_test)
        model_test.eval()
        val_arr = model_test.layers[layer_num].attention.wo.weight.detach().cpu().numpy()
        left_sv, right_sv, sing_values = get_svd(val_arr)

        lst_sim = []
        lst_sim2 = []
        for i in range(100):
            lst_sim.append(left_sv[i])
            lst_sim2.append(right_sv[i])

        arr_sim = np.transpose(np.array(lst_sim))
        arr_sim_transpose = np.transpose(arr_sim)

        arr_sim2 = np.transpose(np.array(lst_sim2))
        arr_sim2_transpose = np.transpose(arr_sim2)

        proj_arr = np.matmul(arr_sim, np.matmul(np.linalg.inv(np.matmul(arr_sim_transpose, arr_sim)), arr_sim_transpose))
        proj_arr2 = np.matmul(arr_sim2, np.matmul(np.linalg.inv(np.matmul(arr_sim2_transpose, arr_sim2)), arr_sim2_transpose))

        val_arr_pretrain = model2.layers[layer_num].attention.wo.weight.detach().cpu().numpy()
        left_sv_pretrain, right_sv_pretrain, sing_values_pretrain = get_svd(val_arr_pretrain)

        lst_sim_pretrain = []
        lst_sim2_pretrain = []
        for i in range(100):
            lst_sim_pretrain.append(left_sv_pretrain[i])
            lst_sim2_pretrain.append(right_sv_pretrain[i])

        arr_sim_pretrain = np.transpose(np.array(lst_sim_pretrain))
        arr_sim_pretrain_transpose = np.transpose(arr_sim_pretrain)

        arr_sim2_pretrain = np.transpose(np.array(lst_sim2_pretrain))
        arr_sim2_pretrain_transpose = np.transpose(arr_sim2_pretrain)
    
        proj_arr_pretrain = np.matmul(arr_sim_pretrain, np.matmul(np.linalg.inv(np.matmul(arr_sim_pretrain_transpose, arr_sim_pretrain)), arr_sim_pretrain_transpose))
        proj_arr2_pretrain = np.matmul(arr_sim2_pretrain, np.matmul(np.linalg.inv(np.matmul(arr_sim2_pretrain_transpose, arr_sim2_pretrain)), arr_sim2_pretrain_transpose))


        lst_val_safe = []
        lst_val_unsafe = []


        for i in range(100):
            proj_safe = np.matmul(np.transpose(proj_arr_pretrain), lst_sim[i])
            proj_unsafe = np.matmul(np.transpose(proj_arr2_pretrain), lst_sim2[i])

            theta_safe = np.sin(np.arccos(np.matmul(np.transpose(proj_safe),lst_sim[i])/(np.linalg.norm(proj_safe)*np.linalg.norm(lst_sim[i]))))
            theta_unsafe = np.sin(np.arccos(np.matmul(np.transpose(proj_unsafe),lst_sim2[i])/(np.linalg.norm(proj_unsafe)*np.linalg.norm(lst_sim2[i]))))
            lst_val_safe.append(theta_safe)
            lst_val_unsafe.append(theta_unsafe)


        print("lst_val_safe",lst_val_safe)
        print("lst_val_unsafe",lst_val_unsafe)

    
        #plt.scatter(np.arange(len(lst_val_safe)), np.array(lst_val_safe),color='red',s=4)
        input_val = (counter_val-20)%3
        id = (counter_val-20)//3
        axs[id][input_val].scatter(np.arange(len(lst_val_unsafe)), np.array(lst_val_unsafe),color='red',s=2)
        # l2_safe = axs[id][input_val].plot(np.arange(len(sing_values_safe)), np.array(sing_values_safe),color='green', label='sing-val')[0]
        # l2_unsafe = axs[id+2][input_val].plot(np.arange(len(sing_values_unsafe)), np.array(sing_values_unsafe),color='green', label='sing-val')[0]
        # l3_safe = axs[id][input_val].plot(np.arange(len(sing_values_safe_pretrain)), np.array(sing_values_safe_pretrain),color='blue', label='sing-val-pre')[0]
        # l3_unsafe = axs[id+2][input_val].plot(np.arange(len(sing_values_unsafe_pretrain)), np.array(sing_values_unsafe_pretrain),color='blue', label='sing-val-pre')[0]
        axs[id][input_val].set_ylim(0,1)

    plt.savefig("./llama_2b_act_wo/" + 'feed_forwardwo_alpha_{}'.format(layer_num) + ".pdf")
    plt.close('all')



if __name__ == "__main__":
    fire.Fire(main)


